# _*_ coding = UTF-8 _*_
# python3.6 + unittest + selenium3.12.0
# author:jin date:2018/5/30


from selenium import webdriver
import unittest
import time


class MyTest(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)
        self.base_url = 'http://www.youdao.com'

    def test_youdao(self):
        driver = self.driver
        driver.get(self.base_url+'/')
        driver.find_element_by_name('q').clear()
        driver.find_element_by_name('q').send_keys('webdirver')
        driver.find_element_by_tag_name('button').click()
        time.sleep(2)
        title = driver.title
        self.assertEqual(title, 'webdriver - 有道搜索')

    def tearDown(self):
        self.driver.close()


if __name__ == '__main__':
    unittest.main()