# _*_ coding = UTF-8 _*_
# python3.6 + unittest + selenium3.12.0
# author:jin date:2018/5/30


import unittest
from HTMLTestRunner import HTMLTestRunner

test_dir = '../test_project/test_case'
discover = unittest.defaultTestLoader.discover(test_dir, pattern='test*.py')

if __name__ == '__main__':

    # runner = unittest.TextTestRunner()
    #定义报告存放路径
    fp = open('./report/result.html', 'wb')
    #定义测试报告
    runner = HTMLTestRunner(stream=fp, title= '百度搜索测试报告', description='用力执行情况：')
    runner.run(discover)
    fp.close() #关闭文件

