# _*_ coding = UTF-8 _*_
# python3.6 + unittest + selenium3.12.0
# author:jin date:2018/6/7


from selenium import webdriver
import os


# 截图函数
def insert_img(ddriver,file_name):
    base_dir = os.path.dirname(os.path.dirname(__file__))
    base_dir = str(base_dir)
    base_dir = base_dir.replace('\\', '/')
    base = base_dir.split('/test_case')[0]
    file_path = base + '/report/image/' + file_name
    driver.get_screenshot_as_file(file_path)


if __name__ == '__main__':
    driver = webdriver.Chrome()
    driver.get('https://www.baidu.com')
    insert_img(driver,'baidu.png')
    driver.quit()