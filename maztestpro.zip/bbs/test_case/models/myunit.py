# _*_ coding = UTF-8 _*_
# python3.6 + unittest + selenium3.12.0
# author:jin date:2018/6/7


from selenium import webdriver
from .driver import browser
import unittest
import os

class MyTest(unittest.TestCase):

    def setup(self):
        self.driver = browser()
        self.driver.implicitly_wait(10)
        self.driver.maximize_windows()

    def tearDown(self):
        self.driver.quit()